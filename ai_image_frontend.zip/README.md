# AI Image Generator Frontend

This is a Next.js-based frontend for an AI Image Generator.

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```
2. Run the development server:
   ```bash
   npm run dev
   ```

## Usage
Enter a prompt and click "Generate Image" to see the AI-generated image.
