import { useState } from 'react';

export default function Home() {
    const [prompt, setPrompt] = useState('');
    const [imageUrl, setImageUrl] = useState(null);
    const [loading, setLoading] = useState(false);

    const generateImage = async () => {
        if (!prompt) return alert("Please enter a prompt!");
        
        setLoading(true);
        try {
            const response = await fetch(`https://YOUR_BACKEND_URL/generate?prompt=${prompt}`);
            const data = await response.json();
            setImageUrl(data.image_url);
        } catch (error) {
            alert("Error generating image!");
        }
        setLoading(false);
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white">
            <h1 className="text-3xl font-bold mb-4">AI Image Generator</h1>
            <input
                type="text"
                className="p-2 w-96 border rounded text-black"
                placeholder="Enter a prompt..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
            />
            <button onClick={generateImage} className="mt-4 px-4 py-2 bg-blue-500 rounded">
                {loading ? "Generating..." : "Generate Image"}
            </button>
            {imageUrl && <img src={imageUrl} alt="Generated" className="mt-4 w-96 rounded shadow-lg" />}
        </div>
    );
}
